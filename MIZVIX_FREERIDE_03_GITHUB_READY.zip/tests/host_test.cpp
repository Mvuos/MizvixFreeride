// Host-side test of the engine logic (no GL): loads the real models, rides the lane with a simple autopilot.
#include <cstdio>
#include <fstream>
#include <iterator>
#include "../engine/mv_game.h"
using namespace mv;
static std::vector<uint8_t> readFile(const char* p) { std::ifstream f(p, std::ios::binary); return {std::istreambuf_iterator<char>(f), {}}; }
int main(int argc, char** argv) {
    std::string dir = argc > 1 ? argv[1] : "../assets";
    Model forest, bikeM; std::string e;
    auto a = readFile((dir + "/forest.glb").c_str()), b = readFile((dir + "/enduro_bicycle_dh.glb").c_str());
    if (!loadGLB(a.data(), a.size(), forest, e) || !loadGLB(b.data(), b.size(), bikeM, e)) { printf("LOAD ERR %s\n", e.c_str()); return 1; }
    Game g; if (!g.init(forest, bikeM, 1.4f, 12.0f, e)) { printf("INIT ERR %s\n", e.c_str()); return 1; }
    printf("bike: wheelR %.3f wheelBase %.3f\n", g.bike.g.wheelR, g.bike.g.wheelBase);
    float zc = g.world.spawn.z; int lastForks = 0; bool nan = false; float maxSpeed = 0; float tEnd = 0;
    for (int fr = 0; fr < 60 * 90; fr++) {                       // up to 60 s at 60 fps
        BikeInput in; in.throttle = 1;
        float err = zc - g.bike.pos.z; in.steer = clampf(err * 0.8f - g.bike.yaw * 2.0f, -1, 1);
        if (!g.bike.anyGround()) in.lean = clampf(-g.bike.pitch * 3.0f - g.bike.pitchRate * 0.6f, -1, 1);
        g.update(in, 1.0f / 60);
        const Bike& k = g.bike;
        if (!std::isfinite(k.pos.x + k.pos.y + k.pos.z + k.pitch)) { nan = true; break; }
        maxSpeed = std::max(maxSpeed, k.speed());
        if (g.forks != lastForks) { printf("t=%5.2f x=%7.1f y=%5.2f speed=%5.2f  +%d (kind %d) total %d\n", fr / 60.0f, k.pos.x, k.pos.y, k.speed(), g.forks - lastForks, g.lastRewardKind, g.forks); lastForks = g.forks; }
        if (k.pos.x > g.world.spawn.x - 4 + 188) { tEnd = fr / 60.0f; break; }
    }
    printf("nan=%d maxSpeed=%.1f finishedAt=%.1fs forks=%d final pos (%.1f %.2f %.1f) yaw %.2f\n", nan, maxSpeed, tEnd, g.forks, g.bike.pos.x, g.bike.pos.y, g.bike.pos.z, g.bike.yaw);
    return nan ? 1 : 0;
}
