// MIZVIX FREERIDE - currency "вилки" (forks): rewards
#pragma once
namespace mv {
inline int rewardDrop(float heightM) {          // drop height in metres
    if (heightM < 0.5f) return 0;
    if (heightM < 1.0f) return 10;
    if (heightM < 3.0f) return 30;
    return 60;
}
inline int rewardJump(float distM) {            // flight distance in metres
    if (distM < 5.0f) return 0;
    if (distM < 10.0f) return 15;
    if (distM < 15.0f) return 40;
    return 80;
}
inline int rewardStairs(int steps) { return 20 + 2 * steps; }
} // namespace mv
