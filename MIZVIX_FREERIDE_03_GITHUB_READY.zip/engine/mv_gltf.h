// MIZVIX Engine - GLB loader. Vertices are baked into model space (node transforms applied).
#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include "mv_math.h"
namespace mv {
struct Material { std::string name; float color[4] = {1, 1, 1, 1}; int image = -1; bool blend = false, dbl = false; };
// vtx: 8 floats per vertex: position(3) normal(3) uv(2)
struct Prim {
    std::vector<float> vtx; std::vector<uint32_t> idx;
    int mat = 0;
    int tag = 0;              // 0 = body, 1 = front wheel, 2 = rear wheel
    std::string node;
    size_t vcount() const { return vtx.size() / 8; }
};
struct Image { std::vector<uint8_t> bytes; };   // encoded PNG/JPEG, decoded by the platform layer
struct Model { std::vector<Prim> prims; std::vector<Material> mats; std::vector<Image> images; };
bool loadGLB(const uint8_t* data, size_t size, Model& out, std::string& err);
} // namespace mv
