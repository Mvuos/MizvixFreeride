// MIZVIX Engine - world: forest map, procedural bike-park lane (jumps / drops / stairs), ground queries
#pragma once
#include <vector>
#include "mv_gltf.h"
namespace mv {

struct Tri { V3 a, b, c, n; };

struct Zone {                     // rectangular zone in the xz plane
    float x0, z0, x1, z1;
    int type;                     // 1 = stairs (ride in +X direction), 2 = drop edge
    int steps;
    bool contains(float x, float z) const { return x >= x0 && x <= x1 && z >= z0 && z <= z1; }
};

class World {
public:
    Model visual;                 // everything that is drawn (scaled forest + structures)
    std::vector<Zone> zones;
    V3 spawn;                     // axle-level ground position of the start point (ground height, not wheel height)
    float spawnYaw = 0;           // forward = (cos yaw, 0, sin yaw)
    float minY = 0;               // below this the bike is considered fallen out of the world

    // forest: model loaded from forest.glb (Y-up already). scale: how many times to enlarge it.
    bool build(const Model& forest, float scale, std::string& err);

    // Highest surface under (x,z) that is not above yMax. Returns false if there is none.
    bool ground(float x, float z, float yMax, float& h, V3& n) const;

private:
    std::vector<Tri> tris_;
    std::vector<std::vector<int>> cells_;
    float gx0_ = 0, gz0_ = 0, cs_ = 8; int gnx_ = 0, gnz_ = 0;
    void buildGrid();
};
} // namespace mv
