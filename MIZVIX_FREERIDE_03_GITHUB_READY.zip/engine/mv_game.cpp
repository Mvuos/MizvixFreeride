#include "mv_game.h"
namespace mv {

bool Game::init(const Model& forest, Model& bikeModel, float bikeScale, float mapScale, std::string& err) {
    if (!world.build(forest, mapScale, err)) return false;
    if (!prepareBike(bikeModel, bikeScale, bike.g, err)) return false;
    stairsState_.assign(world.zones.size(), 0);
    respawn();
    return true;
}

void Game::respawn() {
    bike.reset(world.spawn, world.spawnYaw);
    flying_ = false; airT_ = 0; haveTakeoff_ = false;
    std::fill(stairsState_.begin(), stairsState_.end(), 0);
}

void Game::award(int amount, int kind) {
    if (amount <= 0) return;
    forks += amount; lastReward = amount; lastRewardT = 0; lastRewardKind = kind;
}

void Game::track(float dt) {
    // --- jumps and drops -------------------------------------------------------------
    if (bike.anyGround()) {
        if (flying_) {
            V3 d = bike.pos - takeoff_; float dist = std::sqrt(d.x * d.x + d.z * d.z);
            float drop = takeoffSurf_ - bike.contactY;     // height of the ground we left minus the ground we landed on
            bool clean = std::fabs(bike.pitch - bike.groundPitch) < 0.7f;   // otherwise it is a bail, no reward
            if (clean && airT_ >= 0.25f) {
                int rd = rewardDrop(drop), rj = rewardJump(dist);
                award(std::max(rd, rj), rd >= rj ? 1 : 2);
            }
            flying_ = false;
        }
        airT_ = 0; lastGrounded_ = bike.pos; lastSurf_ = bike.contactY; haveTakeoff_ = true;
    } else {
        airT_ += dt;
        if (!flying_ && airT_ > 0.25f && haveTakeoff_) { flying_ = true; takeoff_ = lastGrounded_; takeoffSurf_ = lastSurf_; }
    }
    // --- stairs: entered from the top end and left at the bottom end -----------------------
    for (size_t i = 0; i < world.zones.size(); i++) {
        const Zone& z = world.zones[i]; if (z.type != 1) continue;
        bool inside = z.contains(bike.pos.x, bike.pos.z);
        if (inside && stairsState_[i] == 0 && bike.pos.x < z.x0 + 1.5f) stairsState_[i] = 1;
        if (!inside && stairsState_[i] == 1) {
            if (bike.pos.x > z.x1) award(rewardStairs(z.steps), 3);
            stairsState_[i] = 0;
        }
    }
    if (bike.pos.y < world.minY) respawn();
}

void Game::update(const BikeInput& in, float frameDt) {
    const float dt = 1.0f / 240.0f;
    accum_ += std::min(frameDt, 0.1f);
    while (accum_ >= dt) { bike.step(world, in, dt); track(dt); accum_ -= dt; }
    lastRewardT += frameDt;
}
} // namespace mv
