#include "mv_world.h"
#include <cmath>
#include <limits>
namespace mv {
namespace {

struct Builder {
    Prim* prim; std::vector<Tri>* col;
    void tri(V3 a, V3 b, V3 c, bool collide) {
        V3 n = norm(cross(b - a, c - a));
        uint32_t base = (uint32_t)prim->vcount();
        V3 p[3] = {a, b, c};
        for (auto& q : p) { float v[8] = {q.x, q.y, q.z, n.x, n.y, n.z, 0, 0}; prim->vtx.insert(prim->vtx.end(), v, v + 8); }
        prim->idx.push_back(base); prim->idx.push_back(base + 1); prim->idx.push_back(base + 2);
        if (collide) { V3 cn = n; if (cn.y < 0) cn = cn * -1.0f; col->push_back({a, b, c, cn}); }
    }
    void quad(V3 a, V3 b, V3 c, V3 d, bool collide) { tri(a, b, c, collide); tri(a, c, d, collide); }
};

// Extrudes a side profile (u along +X, absolute y) across z in [zc-hw, zc+hw].
void extrude(Builder& B, float x0, float zc, float hw, float yBase, const std::vector<std::pair<float, float>>& pts) {
    float zl = zc - hw, zr = zc + hw;
    for (size_t i = 0; i + 1 < pts.size(); i++) {
        float u0 = x0 + pts[i].first, u1 = x0 + pts[i + 1].first, y0 = pts[i].second, y1 = pts[i + 1].second;
        if (u1 - u0 > 1e-4f) {
            B.quad({u0, y0, zl}, {u0, y0, zr}, {u1, y1, zr}, {u1, y1, zl}, true);                 // top
            B.quad({u0, yBase, zr}, {u1, yBase, zr}, {u1, y1, zr}, {u0, y0, zr}, false);          // +z side
            B.quad({u1, yBase, zl}, {u0, yBase, zl}, {u0, y0, zl}, {u1, y1, zl}, false);          // -z side
        } else if (std::fabs(y1 - y0) > 1e-4f) {                                                  // riser
            if (y1 < y0) B.quad({u0, y1, zl}, {u0, y1, zr}, {u0, y0, zr}, {u0, y0, zl}, false);  // faces +X
            else         B.quad({u0, y0, zr}, {u0, y0, zl}, {u0, y1, zl}, {u0, y1, zr}, false);  // faces -X
        }
    }
    float ua = x0 + pts.front().first, ub = x0 + pts.back().first;
    B.quad({ua, yBase, zr}, {ua, yBase, zl}, {ua, pts.front().second, zl}, {ua, pts.front().second, zr}, false);
    B.quad({ub, yBase, zl}, {ub, yBase, zr}, {ub, pts.back().second, zr}, {ub, pts.back().second, zl}, false);
}

float smooth(float t) { t = clampf(t, 0, 1); return t * t * (3 - 2 * t); }
} // namespace

bool World::build(const Model& forest, float S, std::string& err) {
    visual = forest;
    // scale the whole forest
    int floorIdx = -1;
    for (size_t i = 0; i < visual.prims.size(); i++) {
        Prim& p = visual.prims[i];
        for (size_t v = 0; v < p.vcount(); v++) for (int k = 0; k < 3; k++) p.vtx[v * 8 + k] *= S;
        if (visual.mats[p.mat].name == "Floor") floorIdx = (int)i;
    }
    if (floorIdx < 0) { err = "forest.glb has no Floor mesh"; return false; }
    Prim& fl = visual.prims[floorIdx];

    // ---- choose the lane (flattest strip) --------------------------------------------------
    const float L = 185, W = 10, MARGIN = 14;
    float laneX0 = -93.0f, bestVar = 1e30f, laneZ = 0, laneY = 0;
    auto inRect = [&](float x, float z, float zc, float pad) {
        return x >= laneX0 - pad && x <= laneX0 + L + pad && z >= zc - W * 0.5f - pad && z <= zc + W * 0.5f + pad; };
    for (float zc = -60; zc <= 60; zc += 6) {
        double s = 0, s2 = 0; int n = 0;
        for (size_t v = 0; v < fl.vcount(); v++) {
            float x = fl.vtx[v * 8], y = fl.vtx[v * 8 + 1], z = fl.vtx[v * 8 + 2];
            if (inRect(x, z, zc, 6)) { s += y; s2 += (double)y * y; n++; }
        }
        if (n < 8) continue;
        double mean = s / n, var = s2 / n - mean * mean;
        if (var < bestVar) { bestVar = (float)var; laneZ = zc; laneY = (float)mean; }
    }
    if (bestVar > 1e29f) { err = "no place for the lane"; return false; }
    // flatten the terrain under the lane, blend into the surrounding hills
    for (size_t v = 0; v < fl.vcount(); v++) {
        float x = fl.vtx[v * 8], z = fl.vtx[v * 8 + 2];
        float dx = std::max({laneX0 - x, 0.0f, x - (laneX0 + L)});
        float dz = std::max({(laneZ - W * 0.5f) - z, 0.0f, z - (laneZ + W * 0.5f)});
        float d = std::sqrt(dx * dx + dz * dz);
        float w = 1.0f - smooth(d / MARGIN);
        fl.vtx[v * 8 + 1] = lerpf(fl.vtx[v * 8 + 1], laneY, w);
    }
    // recompute floor normals
    {
        std::vector<V3> acc(fl.vcount());
        for (size_t t = 0; t + 2 < fl.idx.size(); t += 3) {
            V3 p[3]; for (int k = 0; k < 3; k++) { size_t i = fl.idx[t + k] * 8; p[k] = {fl.vtx[i], fl.vtx[i + 1], fl.vtx[i + 2]}; }
            V3 n = cross(p[1] - p[0], p[2] - p[0]); if (n.y < 0) n = n * -1.0f;
            for (int k = 0; k < 3; k++) acc[fl.idx[t + k]] = acc[fl.idx[t + k]] + n;
        }
        for (size_t v = 0; v < fl.vcount(); v++) { V3 n = norm(acc[v]); fl.vtx[v * 8 + 3] = n.x; fl.vtx[v * 8 + 4] = n.y; fl.vtx[v * 8 + 5] = n.z; }
    }
    // clear trees around the lane (their triangles are removed)
    for (size_t i = 0; i < visual.prims.size(); i++) {
        if ((int)i == floorIdx) continue;
        Prim& p = visual.prims[i]; std::vector<uint32_t> keep;
        for (size_t t = 0; t + 2 < p.idx.size(); t += 3) {
            float cx = 0, cz = 0;
            for (int k = 0; k < 3; k++) { cx += p.vtx[p.idx[t + k] * 8]; cz += p.vtx[p.idx[t + k] * 8 + 2]; }
            if (!inRect(cx / 3, cz / 3, laneZ, MARGIN)) keep.insert(keep.end(), p.idx.begin() + t, p.idx.begin() + t + 3);
        }
        p.idx.swap(keep);
    }

    // ---- structures ------------------------------------------------------------------------
    Material dirt; dirt.name = "Dirt";  dirt.color[0] = 0.55f; dirt.color[1] = 0.36f; dirt.color[2] = 0.22f;
    Material conc; conc.name = "Concrete"; conc.color[0] = 0.78f; conc.color[1] = 0.79f; conc.color[2] = 0.82f;
    int mDirt = (int)visual.mats.size(); visual.mats.push_back(dirt);
    int mConc = (int)visual.mats.size(); visual.mats.push_back(conc);
    Prim pDirt, pConc; pDirt.mat = mDirt; pConc.mat = mConc;
    std::vector<Tri> structTris;
    Builder bd{&pDirt, &structTris}, bc{&pConc, &structTris};
    const float b = laneY, yBase = b - 0.6f, hw = 2.2f;

    auto jump = [&](float u0, float h, float up, float top, float down) {
        std::vector<std::pair<float, float>> p;
        const int N = 8;
        for (int i = 0; i <= N; i++) { float t = (float)i / N; p.push_back({u0 + up * t, b + h * std::pow(t, 1.7f)}); }
        p.push_back({u0 + up + top, b + h});
        p.push_back({u0 + up + top + down, b});
        extrude(bd, laneX0, laneZ, hw, yBase, p);
    };
    jump(45, 0.8f, 3.0f, 2.5f, 4.5f);
    jump(65, 1.2f, 4.0f, 3.0f, 6.0f);
    jump(90, 1.8f, 5.0f, 4.0f, 8.0f);

    { // drop platform (parapet): long ramp up, flat top, vertical edge
        float u0 = 125, h = 3.2f;
        extrude(bc, laneX0, laneZ, hw, yBase, {{u0, b}, {u0 + 12, b + h}, {u0 + 18, b + h}, {u0 + 18, b}});
        zones.push_back({laneX0 + u0 + 17, laneZ - hw, laneX0 + u0 + 20, laneZ + hw, 2, 0});
    }
    { // stairs: ramp up, platform, 12 steps down
        float u0 = 160; const int n = 12; const float rise = 0.18f, tread = 0.45f, H = n * rise;
        std::vector<std::pair<float, float>> p = {{u0, b}, {u0 + 10, b + H}, {u0 + 15, b + H}};
        float us = u0 + 15;
        for (int i = 0; i < n; i++) {
            float yy = b + H - i * rise;
            p.push_back({us + i * tread, yy}); p.push_back({us + (i + 1) * tread, yy});
            p.push_back({us + (i + 1) * tread, yy - rise});
        }
        p.push_back({us + n * tread + 0.01f, b});  // keep strictly increasing u at the end
        extrude(bc, laneX0, laneZ, hw, yBase, p);
        zones.push_back({laneX0 + us, laneZ - hw, laneX0 + us + n * tread, laneZ + hw, 1, n});
    }
    // ---- spawn + collision ------------------------------------------------------------------
    spawn = {laneX0 + 4, b, laneZ}; spawnYaw = 0;
    minY = b - 60.0f;
    for (size_t t = 0; t + 2 < fl.idx.size(); t += 3) {
        V3 p[3]; for (int k = 0; k < 3; k++) { size_t i = fl.idx[t + k] * 8; p[k] = {fl.vtx[i], fl.vtx[i + 1], fl.vtx[i + 2]}; }
        V3 n = norm(cross(p[1] - p[0], p[2] - p[0])); if (n.y < 0) n = n * -1.0f;
        tris_.push_back({p[0], p[1], p[2], n});
    }
    for (auto& t : structTris) tris_.push_back(t);
    buildGrid();
    visual.prims.push_back(std::move(pDirt));   // after 'fl' is no longer used (push_back may reallocate)
    visual.prims.push_back(std::move(pConc));
    return true;
}

void World::buildGrid() {
    float lo[2] = {1e30f, 1e30f}, hi[2] = {-1e30f, -1e30f};
    for (auto& t : tris_) for (V3 p : {t.a, t.b, t.c}) { lo[0] = std::min(lo[0], p.x); hi[0] = std::max(hi[0], p.x); lo[1] = std::min(lo[1], p.z); hi[1] = std::max(hi[1], p.z); }
    gx0_ = lo[0] - 1; gz0_ = lo[1] - 1; cs_ = 8;
    gnx_ = (int)((hi[0] - gx0_) / cs_) + 2; gnz_ = (int)((hi[1] - gz0_) / cs_) + 2;
    cells_.assign((size_t)gnx_ * gnz_, {});
    for (size_t i = 0; i < tris_.size(); i++) {
        auto& t = tris_[i];
        float x0 = std::min({t.a.x, t.b.x, t.c.x}), x1 = std::max({t.a.x, t.b.x, t.c.x});
        float z0 = std::min({t.a.z, t.b.z, t.c.z}), z1 = std::max({t.a.z, t.b.z, t.c.z});
        int cx0 = (int)((x0 - gx0_) / cs_), cx1 = (int)((x1 - gx0_) / cs_), cz0 = (int)((z0 - gz0_) / cs_), cz1 = (int)((z1 - gz0_) / cs_);
        for (int cz = cz0; cz <= cz1; cz++) for (int cx = cx0; cx <= cx1; cx++) cells_[(size_t)cz * gnx_ + cx].push_back((int)i);
    }
}

bool World::ground(float x, float z, float yMax, float& h, V3& nOut) const {
    int cx = (int)std::floor((x - gx0_) / cs_), cz = (int)std::floor((z - gz0_) / cs_);
    if (cx < 0 || cz < 0 || cx >= gnx_ || cz >= gnz_) return false;
    float best = -1e30f; bool found = false;
    for (int ti : cells_[(size_t)cz * gnx_ + cx]) {
        const Tri& t = tris_[ti];
        float d = (t.b.z - t.c.z) * (t.a.x - t.c.x) + (t.c.x - t.b.x) * (t.a.z - t.c.z);
        if (std::fabs(d) < 1e-9f) continue;
        float l1 = ((t.b.z - t.c.z) * (x - t.c.x) + (t.c.x - t.b.x) * (z - t.c.z)) / d;
        float l2 = ((t.c.z - t.a.z) * (x - t.c.x) + (t.a.x - t.c.x) * (z - t.c.z)) / d;
        float l3 = 1 - l1 - l2;
        const float e = -1e-4f;
        if (l1 < e || l2 < e || l3 < e) continue;
        float y = l1 * t.a.y + l2 * t.b.y + l3 * t.c.y;
        if (y <= yMax && y > best) { best = y; nOut = t.n; found = true; }
    }
    if (found) h = best;
    return found;
}
} // namespace mv
