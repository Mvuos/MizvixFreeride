#include "mv_gltf.h"
#include "mv_json.h"
#include <cstring>
namespace mv {
namespace {
struct Ctx { J root; const uint8_t* bin = nullptr; size_t binSize = 0; };

int compCount(const std::string& t) {
    if (t == "SCALAR") return 1;
    if (t == "VEC2") return 2;
    if (t == "VEC3") return 3;
    if (t == "VEC4") return 4;
    return 0;
}
int compSize(int ct) { switch (ct) { case 5120: case 5121: return 1; case 5122: case 5123: return 2; default: return 4; } }

float readComp(const uint8_t* p, int ct, bool normalized) {
    switch (ct) {
        case 5126: { float f; memcpy(&f, p, 4); return f; }
        case 5121: return normalized ? *p / 255.0f : (float)*p;
        case 5120: { int8_t v = (int8_t)*p; return normalized ? std::max(v / 127.0f, -1.0f) : (float)v; }
        case 5123: { uint16_t v; memcpy(&v, p, 2); return normalized ? v / 65535.0f : (float)v; }
        case 5122: { int16_t v; memcpy(&v, p, 2); return normalized ? std::max(v / 32767.0f, -1.0f) : (float)v; }
        case 5125: { uint32_t v; memcpy(&v, p, 4); return (float)v; }
    }
    return 0;
}

bool readAccessor(const Ctx& c, int ai, std::vector<float>& out, int& ncomp, std::vector<uint32_t>* idxOut = nullptr) {
    const J& acc = c.root["accessors"][ai];
    if (acc.t != J::OBJ || !acc.has("bufferView")) return false;
    const J& bv = c.root["bufferViews"][acc["bufferView"].i()];
    ncomp = compCount(acc["type"].s);
    int ct = acc["componentType"].i(); int count = acc["count"].i();
    size_t base = (size_t)bv["byteOffset"].i() + (size_t)acc["byteOffset"].i();
    size_t stride = bv.has("byteStride") ? (size_t)bv["byteStride"].i() : (size_t)(ncomp * compSize(ct));
    if (!ncomp || stride == 0) return false;
    size_t need = base + stride * (count > 0 ? count - 1 : 0) + ncomp * compSize(ct);
    if (need > c.binSize) return false;
    bool normalized = acc["normalized"].b;
    if (idxOut) {
        idxOut->resize(count);
        for (int i = 0; i < count; i++) {
            const uint8_t* p = c.bin + base + stride * i;
            if (ct == 5125) { uint32_t v; memcpy(&v, p, 4); (*idxOut)[i] = v; }
            else if (ct == 5123) { uint16_t v; memcpy(&v, p, 2); (*idxOut)[i] = v; }
            else (*idxOut)[i] = *p;
        }
        return true;
    }
    out.resize((size_t)count * ncomp);
    for (int i = 0; i < count; i++)
        for (int k = 0; k < ncomp; k++)
            out[(size_t)i * ncomp + k] = readComp(c.bin + base + stride * i + k * compSize(ct), ct, normalized);
    return true;
}

M4 nodeMatrix(const J& n) {
    if (n.has("matrix") && n["matrix"].size() == 16) { M4 m; for (int i = 0; i < 16; i++) m.m[i] = n["matrix"][i].f(); return m; }
    V3 t{0, 0, 0}; float q[4] = {0, 0, 0, 1}; V3 s{1, 1, 1};
    if (n.has("translation")) t = {n["translation"][0].f(), n["translation"][1].f(), n["translation"][2].f()};
    if (n.has("rotation")) for (int i = 0; i < 4; i++) q[i] = n["rotation"][i].f();
    if (n.has("scale")) s = {n["scale"][0].f(), n["scale"][1].f(), n["scale"][2].f()};
    float x = q[0], y = q[1], z = q[2], w = q[3];
    M4 m = identity();
    m.m[0] = (1 - 2 * (y * y + z * z)) * s.x; m.m[1] = (2 * (x * y + z * w)) * s.x;     m.m[2] = (2 * (x * z - y * w)) * s.x;
    m.m[4] = (2 * (x * y - z * w)) * s.y;     m.m[5] = (1 - 2 * (x * x + z * z)) * s.y; m.m[6] = (2 * (y * z + x * w)) * s.y;
    m.m[8] = (2 * (x * z + y * w)) * s.z;     m.m[9] = (2 * (y * z - x * w)) * s.z;     m.m[10] = (1 - 2 * (x * x + y * y)) * s.z;
    m.m[12] = t.x; m.m[13] = t.y; m.m[14] = t.z;
    return m;
}

void addMesh(const Ctx& c, Model& out, int meshIdx, const M4& W, int tag, const std::string& nodeName) {
    const J& mesh = c.root["meshes"][meshIdx];
    for (size_t pi = 0; pi < mesh["primitives"].size(); pi++) {
        const J& pr = mesh["primitives"][pi];
        if (pr.has("mode") && pr["mode"].i() != 4) continue;
        std::vector<float> pos, nrm, uv; int nc = 0;
        if (!pr["attributes"].has("POSITION") || !readAccessor(c, pr["attributes"]["POSITION"].i(), pos, nc) || nc != 3) continue;
        size_t vc = pos.size() / 3;
        bool hasN = pr["attributes"].has("NORMAL") && readAccessor(c, pr["attributes"]["NORMAL"].i(), nrm, nc) && nc == 3 && nrm.size() == pos.size();
        bool hasT = pr["attributes"].has("TEXCOORD_0") && readAccessor(c, pr["attributes"]["TEXCOORD_0"].i(), uv, nc) && nc == 2 && uv.size() == vc * 2;
        Prim P; P.tag = tag; P.node = nodeName; P.mat = pr.has("material") ? pr["material"].i() : 0;
        if (pr.has("indices")) { std::vector<float> dummy; int n2; if (!readAccessor(c, pr["indices"].i(), dummy, n2, &P.idx)) continue; }
        else { P.idx.resize(vc); for (size_t i = 0; i < vc; i++) P.idx[i] = (uint32_t)i; }
        P.idx.resize(P.idx.size() / 3 * 3);
        bool bad = false; for (auto i : P.idx) if (i >= vc) { bad = true; break; }
        if (bad) continue;
        P.vtx.resize(vc * 8);
        for (size_t i = 0; i < vc; i++) {
            V3 p = xformPoint(W, {pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]});
            P.vtx[i * 8 + 0] = p.x; P.vtx[i * 8 + 1] = p.y; P.vtx[i * 8 + 2] = p.z;
            if (hasN) { V3 n = norm(xformDir(W, {nrm[i * 3], nrm[i * 3 + 1], nrm[i * 3 + 2]}));
                        P.vtx[i * 8 + 3] = n.x; P.vtx[i * 8 + 4] = n.y; P.vtx[i * 8 + 5] = n.z; }
            P.vtx[i * 8 + 6] = hasT ? uv[i * 2] : 0; P.vtx[i * 8 + 7] = hasT ? uv[i * 2 + 1] : 0;
        }
        if (!hasN) { // smooth normals from faces
            std::vector<V3> acc(vc);
            for (size_t t = 0; t + 2 < P.idx.size(); t += 3) {
                V3 a{P.vtx[P.idx[t] * 8], P.vtx[P.idx[t] * 8 + 1], P.vtx[P.idx[t] * 8 + 2]};
                V3 b{P.vtx[P.idx[t + 1] * 8], P.vtx[P.idx[t + 1] * 8 + 1], P.vtx[P.idx[t + 1] * 8 + 2]};
                V3 d{P.vtx[P.idx[t + 2] * 8], P.vtx[P.idx[t + 2] * 8 + 1], P.vtx[P.idx[t + 2] * 8 + 2]};
                V3 n = cross(b - a, d - a);
                for (int k = 0; k < 3; k++) acc[P.idx[t + k]] = acc[P.idx[t + k]] + n;
            }
            for (size_t i = 0; i < vc; i++) { V3 n = norm(acc[i]); P.vtx[i * 8 + 3] = n.x; P.vtx[i * 8 + 4] = n.y; P.vtx[i * 8 + 5] = n.z; }
        }
        out.prims.push_back(std::move(P));
    }
}

void walk(const Ctx& c, Model& out, int ni, const M4& parent, int tag, int depth) {
    if (depth > 64) return;
    const J& n = c.root["nodes"][ni];
    M4 W = mul(parent, nodeMatrix(n));
    std::string name = n["name"].s;
    if (name.find("Wheel_F") != std::string::npos) tag = 1;
    else if (name.find("Wheel_B") != std::string::npos) tag = 2;
    if (n.has("mesh")) addMesh(c, out, n["mesh"].i(), W, tag, name);
    for (size_t i = 0; i < n["children"].size(); i++) walk(c, out, n["children"][i].i(), W, tag, depth + 1);
}
} // namespace

bool loadGLB(const uint8_t* d, size_t size, Model& out, std::string& err) {
    if (size < 20 || memcmp(d, "glTF", 4) != 0) { err = "not a GLB"; return false; }
    Ctx c; size_t off = 12; const uint8_t* jsonData = nullptr; size_t jsonLen = 0;
    while (off + 8 <= size) {
        uint32_t cl, ct; memcpy(&cl, d + off, 4); memcpy(&ct, d + off + 4, 4); off += 8;
        if (off + cl > size) { err = "truncated chunk"; return false; }
        if (ct == 0x4E4F534A) { jsonData = d + off; jsonLen = cl; }
        else if (ct == 0x004E4942 && !c.bin) { c.bin = d + off; c.binSize = cl; }
        off += (cl + 3) & ~3u;
    }
    if (!jsonData || !c.bin) { err = "missing chunks"; return false; }
    if (!parseJson((const char*)jsonData, jsonLen, c.root)) { err = "bad json"; return false; }

    // images
    const J& imgs = c.root["images"];
    for (size_t i = 0; i < imgs.size(); i++) {
        Image im;
        if (imgs[i].has("bufferView")) {
            const J& bv = c.root["bufferViews"][imgs[i]["bufferView"].i()];
            size_t o = (size_t)bv["byteOffset"].i(), l = (size_t)bv["byteLength"].i();
            if (o + l <= c.binSize) im.bytes.assign(c.bin + o, c.bin + o + l);
        }
        out.images.push_back(std::move(im));
    }
    // materials
    const J& mats = c.root["materials"];
    for (size_t i = 0; i < mats.size(); i++) {
        Material m; const J& mj = mats[i]; m.name = mj["name"].s;
        m.blend = mj["alphaMode"].s == "BLEND" || mj["alphaMode"].s == "MASK"; m.dbl = mj["doubleSided"].b;
        const J& pbr = mj["pbrMetallicRoughness"];
        if (pbr.has("baseColorFactor")) for (int k = 0; k < 4; k++) m.color[k] = pbr["baseColorFactor"][k].f(1);
        if (pbr.has("baseColorTexture")) {
            int ti = pbr["baseColorTexture"]["index"].i(-1);
            if (ti >= 0) m.image = c.root["textures"][ti]["source"].i(-1);
        }
        out.mats.push_back(m);
    }
    if (out.mats.empty()) out.mats.push_back(Material());

    int scene = c.root["scene"].i(0);
    const J& roots = c.root["scenes"][scene]["nodes"];
    for (size_t i = 0; i < roots.size(); i++) walk(c, out, roots[i].i(), identity(), 0, 0);
    if (out.prims.empty()) { err = "no geometry"; return false; }
    for (auto& p : out.prims) if (p.mat < 0 || p.mat >= (int)out.mats.size()) p.mat = 0;
    return true;
}
} // namespace mv
