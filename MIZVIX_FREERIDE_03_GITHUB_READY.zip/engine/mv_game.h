// MIZVIX FREERIDE - game state: bike + world + rewards
#pragma once
#include <string>
#include "mv_bike.h"
#include "mv_economy.h"
namespace mv {

class Game {
public:
    World world; Bike bike;
    int forks = 0;                                // currency
    int lastReward = 0; float lastRewardT = 99;   // for the HUD popup
    int lastRewardKind = 0;                       // 1 drop, 2 jump, 3 stairs

    bool init(const Model& forest, Model& bikeModel, float bikeScale, float mapScale, std::string& err);
    void respawn();
    void update(const BikeInput& in, float frameDt);

private:
    bool flying_ = false; float airT_ = 0; V3 takeoff_; float takeoffSurf_ = 0, lastSurf_ = 0; bool haveTakeoff_ = false; V3 lastGrounded_;
    std::vector<int> stairsState_;
    float accum_ = 0;
    void award(int amount, int kind);
    void track(float dt);
};
} // namespace mv
