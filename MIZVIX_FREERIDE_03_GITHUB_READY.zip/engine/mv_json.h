// MIZVIX Engine - tiny JSON parser (enough for glTF)
#pragma once
#include <string>
#include <vector>
#include <utility>
#include <cstdlib>
#include <cstring>
namespace mv {
struct J {
    enum T { NUL, BOOL, NUM, STR, ARR, OBJ } t = NUL;
    double n = 0; bool b = false; std::string s;
    std::vector<J> a; std::vector<std::pair<std::string, J>> o;
    static const J& null() { static J j; return j; }
    bool has(const char* k) const { for (auto& p : o) if (p.first == k) return true; return false; }
    const J& operator[](const char* k) const { for (auto& p : o) if (p.first == k) return p.second; return null(); }
    const J& operator[](size_t i) const { return i < a.size() ? a[i] : null(); }
    const J& operator[](int i) const { return (i >= 0 && (size_t)i < a.size()) ? a[(size_t)i] : null(); }
    size_t size() const { return t == ARR ? a.size() : o.size(); }
    int i(int def = 0) const { return t == NUM ? (int)n : def; }
    float f(float def = 0) const { return t == NUM ? (float)n : def; }
};
struct JParser {
    const char* p; const char* e; bool ok = true;
    void ws() { while (p < e && (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t')) p++; }
    bool lit(const char* w) { size_t l = strlen(w); if ((size_t)(e - p) >= l && !strncmp(p, w, l)) { p += l; return true; } return false; }
    std::string str() {
        std::string r; p++;
        while (p < e && *p != '"') {
            if (*p == '\\' && p + 1 < e) {
                p++;
                switch (*p) { case 'n': r += '\n'; break; case 't': r += '\t'; break; case 'r': r += '\r'; break;
                              case 'u': { r += '?'; if (e - p >= 5) p += 4; break; }
                              default: r += *p; }
                p++;
            } else r += *p++;
        }
        p++; return r;
    }
    J val() {
        J j; ws();
        if (p >= e) { ok = false; return j; }
        if (*p == '{') {
            j.t = J::OBJ; p++; ws();
            if (p < e && *p == '}') { p++; return j; }
            while (p < e && ok) {
                ws(); if (p >= e || *p != '"') { ok = false; break; }
                std::string k = str(); ws();
                if (p >= e || *p != ':') { ok = false; break; } p++;
                J v = val(); j.o.emplace_back(k, std::move(v)); ws();
                if (p < e && *p == ',') { p++; continue; }
                if (p < e && *p == '}') { p++; break; }
                ok = false;
            }
        } else if (*p == '[') {
            j.t = J::ARR; p++; ws();
            if (p < e && *p == ']') { p++; return j; }
            while (p < e && ok) {
                j.a.push_back(val()); ws();
                if (p < e && *p == ',') { p++; continue; }
                if (p < e && *p == ']') { p++; break; }
                ok = false;
            }
        } else if (*p == '"') { j.t = J::STR; j.s = str(); }
        else if (lit("true")) { j.t = J::BOOL; j.b = true; }
        else if (lit("false")) { j.t = J::BOOL; j.b = false; }
        else if (lit("null")) { j.t = J::NUL; }
        else { char* end = nullptr; j.n = strtod(p, &end); if (end == p) { ok = false; return j; } j.t = J::NUM; p = end; }
        return j;
    }
};
inline bool parseJson(const char* d, size_t n, J& out) { JParser ps{d, d + n}; out = ps.val(); return ps.ok; }
} // namespace mv
