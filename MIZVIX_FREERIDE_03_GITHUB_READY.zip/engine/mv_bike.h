// MIZVIX Engine - bike model preparation + two-wheel suspension physics
#pragma once
#include "mv_gltf.h"
#include "mv_world.h"
namespace mv {

struct BikeGeom {
    float wheelR = 0.35f, wheelBase = 1.1f;
    V3 cF, cB;                       // wheel centres in bike space (x forward, y up, z right)
};
// Re-orients and scales the model: forward = +X, origin = midpoint between the axles.
bool prepareBike(Model& m, float scale, BikeGeom& g, std::string& err);

struct BikeInput { float throttle = 0, brake = 0, steer = 0, lean = 0; };

struct Bike {
    BikeGeom g;
    V3 pos, vel;                     // pos = point midway between the axles
    float yaw = 0, pitch = 0, pitchRate = 0, yawRate = 0;
    float spin[2] = {0, 0};          // [0] front, [1] rear
    bool grounded[2] = {false, false};
    float comp[2] = {0, 0};          // spring compression (m)
    float groundPitch = 0;           // pitch of the ground under the bike
    float contactY = 0;              // height of the ground surface under the wheels that touch it

    void reset(const V3& groundPoint, float yawRad);
    void step(const World& w, const BikeInput& in, float dt);
    V3 forward() const { return {std::cos(yaw), 0, std::sin(yaw)}; }
    float speed() const { return len(vel); }
    bool anyGround() const { return grounded[0] || grounded[1]; }
};
} // namespace mv
