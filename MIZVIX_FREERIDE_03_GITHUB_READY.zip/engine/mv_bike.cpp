#include "mv_bike.h"
namespace mv {

bool prepareBike(Model& m, float scale, BikeGeom& g, std::string& err) {
    V3 lo[3], hi[3]; bool has[3] = {false, false, false};
    for (int t = 0; t < 3; t++) { lo[t] = {1e30f, 1e30f, 1e30f}; hi[t] = {-1e30f, -1e30f, -1e30f}; }
    for (auto& p : m.prims) {
        int t = p.tag; if (t < 1 || t > 2) continue;
        has[t] = true;
        for (size_t i = 0; i < p.vcount(); i++) {
            float* v = &p.vtx[i * 8];
            lo[t] = {std::min(lo[t].x, v[0]), std::min(lo[t].y, v[1]), std::min(lo[t].z, v[2])};
            hi[t] = {std::max(hi[t].x, v[0]), std::max(hi[t].y, v[1]), std::max(hi[t].z, v[2])};
        }
    }
    if (!has[1] || !has[2]) { err = "bike model has no Wheel_F / Wheel_B nodes"; return false; }
    V3 cF = (lo[1] + hi[1]) * 0.5f, cB = (lo[2] + hi[2]) * 0.5f;
    V3 d = cF - cB; float phi = std::atan2(d.z, d.x);
    V3 mid = (cF + cB) * 0.5f;
    M4 R = rotY(phi);
    for (auto& p : m.prims)
        for (size_t i = 0; i < p.vcount(); i++) {
            float* v = &p.vtx[i * 8];
            V3 q = xformDir(R, V3{v[0], v[1], v[2]} - mid) * scale;
            V3 n = norm(xformDir(R, V3{v[3], v[4], v[5]}));
            v[0] = q.x; v[1] = q.y; v[2] = q.z; v[3] = n.x; v[4] = n.y; v[5] = n.z;
        }
    g.cF = xformDir(R, cF - mid) * scale; g.cB = xformDir(R, cB - mid) * scale;
    g.wheelBase = len(g.cF - g.cB);
    g.wheelR = (hi[1].y - lo[1].y) * 0.5f * scale;
    return true;
}

void Bike::reset(const V3& gp, float yawRad) {
    pos = {gp.x, gp.y + g.wheelR + 0.02f, gp.z}; vel = {0, 0, 0}; yaw = yawRad; pitch = 0; pitchRate = 0; yawRate = 0;
    grounded[0] = grounded[1] = false; comp[0] = comp[1] = 0; groundPitch = 0; contactY = gp.y;
}

void Bike::step(const World& w, const BikeInput& in, float dt) {
    const float m = 100.0f, I = 45.0f, grav = 9.81f;
    const float k = 9810.0f, k2 = 60000.0f, travel = 0.2f, damp = 700.0f;
    const float r = g.wheelR;
    V3 f = forward();
    float cp = std::cos(pitch), sp = std::sin(pitch), half = g.wheelBase * 0.5f;
    V3 force{0, -m * grav, 0}; float torque = 0;
    V3 nSum{0, 0, 0}; int nGround = 0; float surfSum = 0;
    const float offs[2] = {+half, -half};
    for (int i = 0; i < 2; i++) {
        V3 a = pos + f * (offs[i] * cp) + V3{0, offs[i] * sp, 0};
        float best = -1e30f, bestH = 0; V3 bn{0, 1, 0}; bool hit = false;
        for (int s = -2; s <= 2; s++) {
            float dx = s * 0.35f * r, h; V3 n;
            if (w.ground(a.x + f.x * dx, a.z + f.z * dx, a.y - r + 0.5f, h, n)) {
                float sup = h + std::sqrt(std::max(r * r - dx * dx, 0.0f));
                if (sup > best) { best = sup; bestH = h; bn = n; hit = true; }
            }
        }
        float c = hit ? best - a.y : -1.0f;
        grounded[i] = c > 0; comp[i] = std::max(c, 0.0f);
        if (c > 0) {
            float cdot = -(vel.y + offs[i] * cp * pitchRate);
            float F = k * c + k2 * std::max(0.0f, c - travel) + damp * cdot;
            F = clampf(F, 0.0f, 15000.0f);
            force = force + bn * F;
            torque += offs[i] * cp * F * bn.y;
            nSum = nSum + bn; nGround++; surfSum += bestH;
        }
        spin[i] += (dot(vel, f) / r) * dt;
    }
    V3 nAvg = nGround ? norm(nSum) : V3{0, 1, 0};
    V3 fg = norm(f - nAvg * dot(f, nAvg));
    if (nGround) { groundPitch = std::asin(clampf(fg.y, -1, 1)); contactY = surfSum / nGround; }

    float vf = dot(vel, fg);
    if (grounded[1]) force = force + fg * (in.throttle * 330.0f * std::max(0.0f, 1.0f - vf / 12.0f));
    float sp2 = len(vel);
    if (sp2 > 1e-3f) force = force - norm(vel) * (0.3f * sp2 * sp2 + (nGround ? 12.0f : 0.0f));

    if (!nGround) torque += in.lean * 140.0f - 3.0f * pitchRate;

    vel = vel + force * (dt / m);
    if (nGround && in.brake > 0) {                       // brakes
        float vfn = dot(vel, fg), dv = std::min(std::fabs(vfn), in.brake * 700.0f / m * dt);
        vel = vel - fg * (vfn > 0 ? dv : -dv);
    }
    if (nGround) {                                       // no sideways sliding
        V3 lat = vel - fg * dot(vel, fg) - nAvg * dot(vel, nAvg);
        float rate = (grounded[0] && grounded[1]) ? 18.0f : 8.0f;
        vel = vel - lat * (1.0f - std::exp(-rate * dt));
    }
    pos = pos + vel * dt;

    pitchRate += torque / I * dt; pitch += pitchRate * dt;
    if (pitch > 1.4f) { pitch = 1.4f; pitchRate = std::min(pitchRate, 0.0f); }
    if (pitch < -1.4f) { pitch = -1.4f; pitchRate = std::max(pitchRate, 0.0f); }

    if (nGround) {                                       // steering
        float vfw = dot(vel, f);
        float delta = 0.5f / (1.0f + (vfw / 7.0f) * (vfw / 7.0f));
        float target = vfw * std::tan(delta * in.steer) / g.wheelBase;
        yawRate += (target - yawRate) * std::min(1.0f, 10.0f * dt);
    } else yawRate *= std::max(0.0f, 1.0f - 0.5f * dt);
    yaw += yawRate * dt;
}
} // namespace mv
