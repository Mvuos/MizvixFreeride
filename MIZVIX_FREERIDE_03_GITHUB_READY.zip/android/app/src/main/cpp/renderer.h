// MIZVIX FREERIDE - OpenGL ES 3.0 renderer (map, bike, HUD)
#pragma once
#include <vector>
#include <cstdint>
#include "../../../../../engine/mv_game.h"
#include <GLES3/gl3.h>
namespace mv {

struct HudBtn { int kind; float cx, cy, r; bool down; };   // kind: 0 left, 1 right, 2 gas, 3 brake, 4 lean up, 5 lean down

class Renderer {
public:
    typedef bool (*DecodeFn)(const uint8_t*, size_t, int&, int&, std::vector<uint8_t>&);
    bool init(const Model& world, const Model& bike, DecodeFn dec);
    void release();
    void draw(const Game& g, int W, int H, const std::vector<HudBtn>& hud);
private:
    struct GP { GLuint vao = 0, vbo = 0, ibo = 0; GLsizei n = 0; };
    struct GM { std::vector<GP> prims; std::vector<GLuint> tex; };
    GM world_, bike_; const Model* bikeM_ = nullptr;
    GLuint prog_ = 0, hudProg_ = 0, white_ = 0, hudVao_ = 0, hudVbo_ = 0;
    GLint uVP_, uM_, uColor_, uTex_, uCam_, uAlpha_, uHudScr_;
    float camYaw_ = 0; bool camInit_ = false;
    std::vector<float> hv_;
    void upload(const Model& m, GM& gm, DecodeFn dec);
    void freeModel(GM& gm);
    void drawModel(const Model& m, const GM& gm, const M4* bikeBase, const Game* g);
    void hudRect(float x0, float y0, float x1, float y1, float a);
    void hudTri(float ax, float ay, float bx, float by, float cx, float cy, float a);
    void hudCircle(float cx, float cy, float r, float a);
    void hudNumber(float x, float y, float h, int value, float a);
    void hudFlush();
};
} // namespace mv
