// MIZVIX FREERIDE - Android entry point (NativeActivity): EGL, assets, touch controls, main loop
#include <android_native_app_glue.h>
#include <android/log.h>
#include <android/asset_manager.h>
#include <android/imagedecoder.h>
#include <android/bitmap.h>
#include <EGL/egl.h>
#include <time.h>
#include "../../../../../engine/mv_game.h"
#include "renderer.h"
using namespace mv;
#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "MIZVIX", __VA_ARGS__)

struct Touch { bool down = false; float x = 0, y = 0; };
struct App {
    android_app* app = nullptr;
    EGLDisplay dpy = EGL_NO_DISPLAY; EGLSurface surf = EGL_NO_SURFACE; EGLContext ctx = EGL_NO_CONTEXT;
    bool loaded = false, glReady = false;
    Model bikeM; Game game; Renderer rend;
    Touch t[16]; int W = 1280, H = 720; double last = 0;
};

static double nowSec() { timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts); return ts.tv_sec + ts.tv_nsec * 1e-9; }

static bool readAsset(AAssetManager* am, const char* name, std::vector<uint8_t>& out) {
    AAsset* a = AAssetManager_open(am, name, AASSET_MODE_STREAMING); if (!a) return false;
    size_t n = (size_t)AAsset_getLength(a); out.resize(n); size_t got = 0;
    while (got < n) { int r = AAsset_read(a, out.data() + got, n - got); if (r <= 0) break; got += (size_t)r; }
    AAsset_close(a); return got == n;
}

static bool decodeImage(const uint8_t* d, size_t n, int& w, int& h, std::vector<uint8_t>& px) {
    AImageDecoder* dec = nullptr;
    if (AImageDecoder_createFromBuffer(d, n, &dec) != ANDROID_IMAGE_DECODER_SUCCESS) return false;
    const AImageDecoderHeaderInfo* info = AImageDecoder_getHeaderInfo(dec);
    w = AImageDecoderHeaderInfo_getWidth(info); h = AImageDecoderHeaderInfo_getHeight(info);
    AImageDecoder_setAndroidBitmapFormat(dec, ANDROID_BITMAP_FORMAT_RGBA_8888);
    AImageDecoder_setUnpremultipliedRequired(dec, true);
    size_t stride = AImageDecoder_getMinimumStride(dec); px.resize(stride * (size_t)h);
    int r = AImageDecoder_decodeImage(dec, px.data(), stride, px.size());
    AImageDecoder_delete(dec);
    return r == ANDROID_IMAGE_DECODER_SUCCESS && stride == (size_t)w * 4;
}

static bool initEGL(App& a) {
    a.dpy = eglGetDisplay(EGL_DEFAULT_DISPLAY); eglInitialize(a.dpy, nullptr, nullptr);
    const EGLint cfgAttr[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                              EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg; EGLint n = 0;
    if (!eglChooseConfig(a.dpy, cfgAttr, &cfg, 1, &n) || n < 1) return false;
    EGLint fmt; eglGetConfigAttrib(a.dpy, cfg, EGL_NATIVE_VISUAL_ID, &fmt);
    ANativeWindow_setBuffersGeometry(a.app->window, 0, 0, fmt);
    a.surf = eglCreateWindowSurface(a.dpy, cfg, a.app->window, nullptr);
    const EGLint ctxAttr[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    a.ctx = eglCreateContext(a.dpy, cfg, EGL_NO_CONTEXT, ctxAttr);
    if (a.surf == EGL_NO_SURFACE || a.ctx == EGL_NO_CONTEXT) return false;
    if (eglMakeCurrent(a.dpy, a.surf, a.surf, a.ctx) != EGL_TRUE) return false;
    eglSwapInterval(a.dpy, 1); return true;
}
static void termEGL(App& a) {
    if (a.dpy != EGL_NO_DISPLAY) {
        eglMakeCurrent(a.dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (a.ctx != EGL_NO_CONTEXT) eglDestroyContext(a.dpy, a.ctx);
        if (a.surf != EGL_NO_SURFACE) eglDestroySurface(a.dpy, a.surf);
        eglTerminate(a.dpy);
    }
    a.dpy = EGL_NO_DISPLAY; a.surf = EGL_NO_SURFACE; a.ctx = EGL_NO_CONTEXT;
}

static bool loadGame(App& a) {
    AAssetManager* am = a.app->activity->assetManager;
    std::vector<uint8_t> fb, bb; std::string err; Model forest;
    if (!readAsset(am, "forest.glb", fb) || !readAsset(am, "enduro_bicycle_dh.glb", bb)) { LOG("assets missing"); return false; }
    if (!loadGLB(fb.data(), fb.size(), forest, err) || !loadGLB(bb.data(), bb.size(), a.bikeM, err)) { LOG("glb: %s", err.c_str()); return false; }
    if (!a.game.init(forest, a.bikeM, 1.4f, 12.0f, err)) { LOG("init: %s", err.c_str()); return false; }
    return true;
}

static int32_t onInput(android_app* app, AInputEvent* ev) {
    App* a = (App*)app->userData;
    if (AInputEvent_getType(ev) != AINPUT_EVENT_TYPE_MOTION) return 0;
    int32_t act = AMotionEvent_getAction(ev), m = act & AMOTION_EVENT_ACTION_MASK;
    int idx = (act & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    size_t cnt = AMotionEvent_getPointerCount(ev);
    auto setP = [&](size_t i, bool down) {
        int id = AMotionEvent_getPointerId(ev, i); if (id < 0 || id >= 16) return;
        a->t[id].down = down; a->t[id].x = AMotionEvent_getX(ev, i); a->t[id].y = AMotionEvent_getY(ev, i);
    };
    if (m == AMOTION_EVENT_ACTION_MOVE) { for (size_t i = 0; i < cnt; i++) setP(i, true); }
    else if (m == AMOTION_EVENT_ACTION_DOWN || m == AMOTION_EVENT_ACTION_POINTER_DOWN) setP((size_t)idx, true);
    else if (m == AMOTION_EVENT_ACTION_UP || m == AMOTION_EVENT_ACTION_POINTER_UP) setP((size_t)idx, false);
    else if (m == AMOTION_EVENT_ACTION_CANCEL) { for (auto& t : a->t) t.down = false; }
    return 1;
}

static void onCmd(android_app* app, int32_t cmd) {
    App* a = (App*)app->userData;
    switch (cmd) {
    case APP_CMD_INIT_WINDOW:
        if (!app->window) break;
        if (!initEGL(*a)) { LOG("EGL failed"); ANativeActivity_finish(app->activity); break; }
        if (!a->loaded) { if (!loadGame(*a)) { ANativeActivity_finish(app->activity); break; } a->loaded = true; }
        if (!a->rend.init(a->game.world.visual, a->bikeM, decodeImage)) { ANativeActivity_finish(app->activity); break; }
        a->glReady = true; a->last = nowSec(); break;
    case APP_CMD_TERM_WINDOW:
        if (a->glReady) a->rend.release();
        a->glReady = false; termEGL(*a); break;
    case APP_CMD_LOST_FOCUS: for (auto& t : a->t) t.down = false; break;
    }
}

static void frame(App& a) {
    EGLint w = 0, h = 0; eglQuerySurface(a.dpy, a.surf, EGL_WIDTH, &w); eglQuerySurface(a.dpy, a.surf, EGL_HEIGHT, &h);
    if (w > 0 && h > 0) { a.W = w; a.H = h; }
    float W = (float)a.W, H = (float)a.H, R = H * 0.11f;
    std::vector<HudBtn> hud = {
        {0, R * 1.5f, H - R * 1.5f, R, false},
        {1, R * 4.0f, H - R * 1.5f, R, false},
        {3, W - R * 4.6f, H - R * 1.5f, R, false},
        {2, W - R * 1.6f, H - R * 1.6f, R * 1.25f, false},
        {4, W - R * 1.2f, H - R * 4.6f, R * 0.75f, false},
        {5, W - R * 3.2f, H - R * 4.6f, R * 0.75f, false},
    };
    for (HudBtn& b : hud)
        for (const Touch& t : a.t) if (t.down) { float dx = t.x - b.cx, dy = t.y - b.cy; if (dx * dx + dy * dy <= b.r * b.r * 1.44f) b.down = true; }
    BikeInput in;
    for (const HudBtn& b : hud) if (b.down) switch (b.kind) {
        case 0: in.steer -= 1; break; case 1: in.steer += 1; break;
        case 2: in.throttle = 1; break; case 3: in.brake = 1; break;
        case 4: in.lean += 1; break; case 5: in.lean -= 1; break;
    }
    double t = nowSec(); float dt = (float)(t - a.last); a.last = t; if (dt > 0.05f) dt = 0.05f;
    a.game.update(in, dt);
    a.rend.draw(a.game, a.W, a.H, hud);
    eglSwapBuffers(a.dpy, a.surf);
}

void android_main(android_app* app) {
    static App S; S.app = app; app->userData = &S; app->onAppCmd = onCmd; app->onInputEvent = onInput;
    while (true) {
        int ev; android_poll_source* src;
        while (ALooper_pollOnce(S.glReady ? 0 : -1, nullptr, &ev, (void**)&src) >= 0) {
            if (src) src->process(app, src);
            if (app->destroyRequested) { if (S.glReady) S.rend.release(); termEGL(S); return; }
        }
        if (S.glReady) frame(S);
    }
}
