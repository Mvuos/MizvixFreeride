#include "renderer.h"
#include <cstdio>
#include <algorithm>
namespace mv {

static const char* VS = R"(#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNrm; layout(location=2) in vec2 aUv;
uniform mat4 uVP; uniform mat4 uM;
out vec3 vN; out vec2 vUv; out vec3 vW;
void main(){ vec4 w = uM * vec4(aPos,1.0); vW = w.xyz; vN = mat3(uM) * aNrm; vUv = aUv; gl_Position = uVP * w; })";
static const char* FS = R"(#version 300 es
precision mediump float;
in vec3 vN; in vec2 vUv; in vec3 vW;
uniform sampler2D uTex; uniform vec4 uColor; uniform vec3 uCam; uniform float uAlpha;
out vec4 oC;
void main(){
  vec4 t = texture(uTex, vUv) * uColor;
  if (t.a < uAlpha) discard;
  vec3 n = normalize(vN); if (!gl_FrontFacing) n = -n;
  float l = 0.38 + 0.62 * max(dot(n, normalize(vec3(0.45,0.8,0.35))), 0.0);
  vec3 c = t.rgb * l;
  float d = length(vW - uCam);
  float f = clamp((d - 45.0) / 170.0, 0.0, 1.0);
  c = mix(c, vec3(0.70,0.80,0.88), f);
  oC = vec4(c, 1.0);
})";
static const char* HVS = R"(#version 300 es
layout(location=0) in vec2 aP; layout(location=1) in float aA; uniform vec2 uScr; out float vA;
void main(){ vA = aA; gl_Position = vec4(aP.x / uScr.x * 2.0 - 1.0, 1.0 - aP.y / uScr.y * 2.0, 0.0, 1.0); })";
static const char* HFS = R"(#version 300 es
precision mediump float; in float vA; out vec4 oC; void main(){ oC = vec4(1.0, 1.0, 1.0, vA); })";

static GLuint compile(GLenum t, const char* s) {
    GLuint sh = glCreateShader(t); glShaderSource(sh, 1, &s, nullptr); glCompileShader(sh);
    GLint ok = 0; glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (!ok) { char b[512]; glGetShaderInfoLog(sh, 512, nullptr, b); __builtin_trap(); }
    return sh;
}
static GLuint link(const char* vs, const char* fs) {
    GLuint p = glCreateProgram(); GLuint a = compile(GL_VERTEX_SHADER, vs), b = compile(GL_FRAGMENT_SHADER, fs);
    glAttachShader(p, a); glAttachShader(p, b); glLinkProgram(p); glDeleteShader(a); glDeleteShader(b); return p;
}

bool Renderer::init(const Model& world, const Model& bike, DecodeFn dec) {
    bikeM_ = &bike; prog_ = link(VS, FS); hudProg_ = link(HVS, HFS);
    uVP_ = glGetUniformLocation(prog_, "uVP"); uM_ = glGetUniformLocation(prog_, "uM");
    uColor_ = glGetUniformLocation(prog_, "uColor"); uTex_ = glGetUniformLocation(prog_, "uTex");
    uCam_ = glGetUniformLocation(prog_, "uCam"); uAlpha_ = glGetUniformLocation(prog_, "uAlpha");
    uHudScr_ = glGetUniformLocation(hudProg_, "uScr");
    uint8_t px[4] = {255, 255, 255, 255};
    glGenTextures(1, &white_); glBindTexture(GL_TEXTURE_2D, white_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glGenVertexArrays(1, &hudVao_); glGenBuffers(1, &hudVbo_);
    glBindVertexArray(hudVao_); glBindBuffer(GL_ARRAY_BUFFER, hudVbo_);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 12, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 1, GL_FLOAT, GL_FALSE, 12, (void*)8);
    upload(world, world_, dec); upload(bike, bike_, dec);
    camInit_ = false; return true;
}

void Renderer::upload(const Model& m, GM& gm, DecodeFn dec) {
    gm.tex.assign(m.images.size(), 0);
    for (size_t i = 0; i < m.images.size(); i++) {
        int w = 0, h = 0; std::vector<uint8_t> px;
        if (!dec(m.images[i].bytes.data(), m.images[i].bytes.size(), w, h, px)) { gm.tex[i] = white_; continue; }
        GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
        glGenerateMipmap(GL_TEXTURE_2D);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        gm.tex[i] = t;
    }
    gm.prims.resize(m.prims.size());
    for (size_t i = 0; i < m.prims.size(); i++) {
        const Prim& p = m.prims[i]; GP& g = gm.prims[i];
        glGenVertexArrays(1, &g.vao); glGenBuffers(1, &g.vbo); glGenBuffers(1, &g.ibo);
        glBindVertexArray(g.vao);
        glBindBuffer(GL_ARRAY_BUFFER, g.vbo); glBufferData(GL_ARRAY_BUFFER, p.vtx.size() * 4, p.vtx.data(), GL_STATIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g.ibo); glBufferData(GL_ELEMENT_ARRAY_BUFFER, p.idx.size() * 4, p.idx.data(), GL_STATIC_DRAW);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (void*)0);
        glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 32, (void*)12);
        glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 32, (void*)24);
        g.n = (GLsizei)p.idx.size();
    }
    glBindVertexArray(0);
}
void Renderer::freeModel(GM& gm) {
    for (auto& g : gm.prims) { glDeleteBuffers(1, &g.vbo); glDeleteBuffers(1, &g.ibo); glDeleteVertexArrays(1, &g.vao); }
    for (GLuint t : gm.tex) if (t && t != white_) glDeleteTextures(1, &t);
    gm.prims.clear(); gm.tex.clear();
}
void Renderer::release() {
    freeModel(world_); freeModel(bike_);
    if (white_) glDeleteTextures(1, &white_);
    if (prog_) glDeleteProgram(prog_); if (hudProg_) glDeleteProgram(hudProg_);
    if (hudVbo_) glDeleteBuffers(1, &hudVbo_); if (hudVao_) glDeleteVertexArrays(1, &hudVao_);
    prog_ = hudProg_ = white_ = hudVao_ = hudVbo_ = 0;
}

// bikeBase != null: draw the bike with this base matrix (wheels spin around their axles)
void Renderer::drawModel(const Model& m, const GM& gm, const M4* base, const Game* g) {
    for (size_t i = 0; i < m.prims.size(); i++) {
        const Prim& p = m.prims[i]; const Material& mt = m.mats[std::max(0, std::min(p.mat, (int)m.mats.size() - 1))];
        M4 M = base ? *base : identity();
        if (base && (p.tag == 1 || p.tag == 2)) {
            V3 c = p.tag == 1 ? g->bike.g.cF : g->bike.g.cB; float sp = g->bike.spin[p.tag == 1 ? 0 : 1];
            M = mul(M, mul(translate(c), mul(rotZ(-sp), translate(V3{-c.x, -c.y, -c.z}))));
        }
        glUniformMatrix4fv(uM_, 1, GL_FALSE, M.m);
        glUniform4fv(uColor_, 1, mt.color);
        glUniform1f(uAlpha_, mt.blend ? 0.45f : -1.0f);
        GLuint tx = (mt.image >= 0 && mt.image < (int)gm.tex.size()) ? gm.tex[mt.image] : white_;
        glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, tx ? tx : white_); glUniform1i(uTex_, 0);
        if (mt.dbl) glDisable(GL_CULL_FACE); else glEnable(GL_CULL_FACE);
        glBindVertexArray(gm.prims[i].vao); glDrawElements(GL_TRIANGLES, gm.prims[i].n, GL_UNSIGNED_INT, nullptr);
    }
}

void Renderer::draw(const Game& g, int W, int H, const std::vector<HudBtn>& hud) {
    const Bike& b = g.bike;
    if (!camInit_) { camYaw_ = b.yaw; camInit_ = true; }
    float d = b.yaw - camYaw_; while (d > 3.14159f) d -= 6.28318f; while (d < -3.14159f) d += 6.28318f;
    camYaw_ += d * 0.06f;
    V3 dir{std::cos(camYaw_), 0, std::sin(camYaw_)};
    V3 eye = b.pos - dir * 4.2f + V3{0, 1.7f, 0}, at = b.pos + dir * 2.0f + V3{0, 0.4f, 0};
    float gh; V3 gn;
    if (g.world.ground(eye.x, eye.z, eye.y + 30.0f, gh, gn) && eye.y < gh + 0.7f) eye.y = gh + 0.7f;
    M4 VP = mul(perspective(1.0f, (float)W / (float)H, 0.1f, 500.0f), lookAt(eye, at, V3{0, 1, 0}));

    glViewport(0, 0, W, H); glClearColor(0.70f, 0.80f, 0.88f, 1); glDepthMask(GL_TRUE);
    glEnable(GL_DEPTH_TEST); glDisable(GL_BLEND);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram(prog_); glUniformMatrix4fv(uVP_, 1, GL_FALSE, VP.m); glUniform3f(uCam_, eye.x, eye.y, eye.z);
    drawModel(g.world.visual, world_, nullptr, nullptr);
    M4 base = mul(translate(b.pos), mul(rotY(-b.yaw), rotZ(b.pitch)));
    drawModel(*bikeM_, bike_, &base, &g);

    // ---- HUD ----
    glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glUseProgram(hudProg_); glUniform2f(uHudScr_, (float)W, (float)H);
    hv_.clear(); float u = H * 0.05f;
    // forks counter: icon + number
    float ix = u * 0.8f, iy = u * 0.7f;
    hudRect(ix + u * 0.42f, iy + u * 0.9f, ix + u * 0.58f, iy + u * 2.0f, 0.9f);          // handle
    hudRect(ix, iy + u * 0.55f, ix + u, iy + u * 0.9f, 0.9f);                              // crossbar
    for (int t = 0; t < 3; t++) hudRect(ix + t * u * 0.42f, iy, ix + t * u * 0.42f + u * 0.16f, iy + u * 0.6f, 0.9f);  // tines
    hudNumber(ix + u * 1.5f, iy, u * 1.5f, g.forks, 0.95f);
    if (g.lastRewardT < 2.0f && g.lastReward > 0) {                                        // +reward popup
        float a = g.lastRewardT < 1.2f ? 1.0f : (2.0f - g.lastRewardT) / 0.8f; float h = u * 2.0f, x = W * 0.5f - h * 1.2f, y = H * 0.18f - g.lastRewardT * u * 0.5f;
        hudRect(x, y + h * 0.42f, x + h * 0.4f, y + h * 0.52f, a); hudRect(x + h * 0.15f, y + h * 0.27f, x + h * 0.25f, y + h * 0.67f, a);
        hudNumber(x + h * 0.6f, y, h, g.lastReward, a);
    }
    for (const HudBtn& hb : hud) {
        float a = hb.down ? 0.55f : 0.22f, r = hb.r, s = r * 0.45f;
        hudCircle(hb.cx, hb.cy, r, a);
        float ia = hb.down ? 0.95f : 0.65f;
        switch (hb.kind) {
            case 0: hudTri(hb.cx - s, hb.cy, hb.cx + s * 0.8f, hb.cy - s, hb.cx + s * 0.8f, hb.cy + s, ia); break;
            case 1: hudTri(hb.cx + s, hb.cy, hb.cx - s * 0.8f, hb.cy - s, hb.cx - s * 0.8f, hb.cy + s, ia); break;
            case 2: hudTri(hb.cx - s * 0.8f, hb.cy - s, hb.cx - s * 0.8f, hb.cy + s, hb.cx + s, hb.cy, ia); break;
            case 3: hudRect(hb.cx - s * 0.8f, hb.cy - s * 0.8f, hb.cx + s * 0.8f, hb.cy + s * 0.8f, ia); break;
            case 4: hudTri(hb.cx, hb.cy - s, hb.cx - s, hb.cy + s * 0.8f, hb.cx + s, hb.cy + s * 0.8f, ia); break;
            case 5: hudTri(hb.cx, hb.cy + s, hb.cx - s, hb.cy - s * 0.8f, hb.cx + s, hb.cy - s * 0.8f, ia); break;
        }
    }
    hudFlush();
}

void Renderer::hudRect(float x0, float y0, float x1, float y1, float a) { hudTri(x0, y0, x1, y0, x1, y1, a); hudTri(x0, y0, x1, y1, x0, y1, a); }
void Renderer::hudTri(float ax, float ay, float bx, float by, float cx, float cy, float a) {
    const float v[9] = {ax, ay, a, bx, by, a, cx, cy, a}; hv_.insert(hv_.end(), v, v + 9);
}
void Renderer::hudCircle(float cx, float cy, float r, float a) {
    const int N = 28;
    for (int i = 0; i < N; i++) {
        float a0 = i * 6.2831853f / N, a1 = (i + 1) * 6.2831853f / N;
        hudTri(cx, cy, cx + std::cos(a0) * r, cy + std::sin(a0) * r, cx + std::cos(a1) * r, cy + std::sin(a1) * r, a);
    }
}
// seven-segment digits
void Renderer::hudNumber(float x, float y, float h, int value, float a) {
    static const int seg[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};  // a b c d e f g
    char buf[16]; int n = snprintf(buf, sizeof buf, "%d", value < 0 ? 0 : value);
    float w = h * 0.55f, t = h * 0.12f, gap = h * 0.3f;
    for (int i = 0; i < n; i++) {
        int m = seg[buf[i] - '0']; float x0 = x + i * (w + gap), x1 = x0 + w, y0 = y, y1 = y + h, ym = y + h * 0.5f;
        if (m & 1) hudRect(x0, y0, x1, y0 + t, a);                      // top
        if (m & 2) hudRect(x1 - t, y0, x1, ym, a);                      // top right
        if (m & 4) hudRect(x1 - t, ym, x1, y1, a);                      // bottom right
        if (m & 8) hudRect(x0, y1 - t, x1, y1, a);                      // bottom
        if (m & 16) hudRect(x0, ym, x0 + t, y1, a);                     // bottom left
        if (m & 32) hudRect(x0, y0, x0 + t, ym, a);                     // top left
        if (m & 64) hudRect(x0, ym - t * 0.5f, x1, ym + t * 0.5f, a);   // middle
    }
}
void Renderer::hudFlush() {
    if (hv_.empty()) return;
    glBindVertexArray(hudVao_); glBindBuffer(GL_ARRAY_BUFFER, hudVbo_);
    glBufferData(GL_ARRAY_BUFFER, hv_.size() * 4, hv_.data(), GL_STREAM_DRAW);
    glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(hv_.size() / 3));
}
} // namespace mv
